Thank you for your template purchase.
Please use the following link to view template installation instructions and documentation.
http://support.azelab.com/milan/