<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{homefeatured_mod}prestashop>homefeatured_mod_03c2e7e41ffc181a4e84080b4710e81e'] = 'Neu';
