<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{twitterwidget}prestashop>twitterwidget_c3527078bab902efe0e19ac9875b795d'] = 'Seguici';
