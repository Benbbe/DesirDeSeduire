<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{twitterwidget}prestashop>twitterwidget_d5d7cd4c7fb2e91526e0e889d7386cf2'] = 'Tweet Dernière';
$_MODULE['<{twitterwidget}prestashop>twitterwidget_c3527078bab902efe0e19ac9875b795d'] = 'Suivez-nous';
