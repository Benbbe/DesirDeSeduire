<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blocksocial}prestashop>blocksocial_3c3fcc2aa9705117ce4b589ed5a72853'] = 'Social networking block';
$_MODULE['<{blocksocial}prestashop>blocksocial_094d3ac865853e0be9ba42e80f0f7ee7']
    = 'Allows you to add information about your brand\'s social networking accounts.';
$_MODULE['<{blocksocial}prestashop>blocksocial_f4f70727dc34561dfde1a3c529b6205c'] = 'Settings';
$_MODULE['<{blocksocial}prestashop>blocksocial_76f8961bb8f4bb2b95c07650f30a7e7b'] = 'Facebook URL';
$_MODULE['<{blocksocial}prestashop>blocksocial_c162369096f0fe5784f05052ceee6b47'] = 'Your Facebook fan page.';
$_MODULE['<{blocksocial}prestashop>blocksocial_bcca29e10968edaf6e0154d2339ad556'] = 'Twitter URL';
$_MODULE['<{blocksocial}prestashop>blocksocial_1912cacf8a06a4eaa878c7313593715a'] = 'Your official Twitter accounts.';
$_MODULE['<{blocksocial}prestashop>blocksocial_1a530e4877d8d41f810d9d05f065722d'] = 'RSS URL';
$_MODULE['<{blocksocial}prestashop>blocksocial_672f301ddc5372b2477ed3c1d9322949']
    = 'The RSS feed of your choice (your blog, your store, etc.).';
$_MODULE['<{blocksocial}prestashop>blocksocial_ad7198d676478ac70c3243c1d3446331'] = 'YouTube URL';
$_MODULE['<{blocksocial}prestashop>blocksocial_5817a34292f074f9f596de6cb3607540'] = 'Your official YouTube account.';
$_MODULE['<{blocksocial}prestashop>blocksocial_85eac9d4572e285262a3e76130dcb4ea'] = 'Google Plus URL:';
$_MODULE['<{blocksocial}prestashop>blocksocial_be1d482ea5d68e157ad2ebe18612a4b1'] = 'You official Google Plus page.';
$_MODULE['<{blocksocial}prestashop>blocksocial_76abe3a162f22f63fae44d60fbe8f11b'] = 'Pinterest URL:';
$_MODULE['<{blocksocial}prestashop>blocksocial_e158a81859319b5e442bc490b0e81af3'] = 'Your official Pinterest account.';
$_MODULE['<{blocksocial}prestashop>blocksocial_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{blocksocial}prestashop>blocksocial_d918f99442796e88b6fe5ad32c217f76'] = 'Follow us';
$_MODULE['<{blocksocial}prestashop>blocksocial_d85544fce402c7a2a96a48078edaf203'] = 'Facebook';
$_MODULE['<{blocksocial}prestashop>blocksocial_2491bc9c7d8731e1ae33124093bc7026'] = 'Twitter';
$_MODULE['<{blocksocial}prestashop>blocksocial_bf1981220040a8ac147698c85d55334f'] = 'RSS';
$_MODULE['<{blocksocial}prestashop>blocksocial_8dd1bae8da2e2408210d0656fbe6b7d1'] = 'YouTube';
$_MODULE['<{blocksocial}prestashop>blocksocial_5b2c8bfd1bc974966209b7be1cb51a72'] = 'Google+';
$_MODULE['<{blocksocial}prestashop>blocksocial_86709a608bd914b28221164e6680ebf7'] = 'Pinterest';
$_MODULE['<{blocksocial}prestashop>blocksocial_970cfba66b8380fb97b742e4571356c6'] = 'Youtube';
$_MODULE['<{blocksocial}prestashop>blocksocial_dda8dc38128a8c843ba9f496d6ee7186'] = 'Google Plus';

return $_MODULE;
